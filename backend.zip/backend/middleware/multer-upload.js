const { profileUpload } = require("../config/s3-config");

module.exports = profileUpload;
